// ler um vetor com 10 valores inteiros
// encontrar o maior valor par desse vetor
#include <stdio.h>
#define T 10
int main () {
	int mvp, v[T], i, j; 
	printf ("digite %d valores para o vetor:\n", T);
	for (i=0; i<T; i++) {
		printf ("valor %d: ", i);
		scanf ("%d", &v[i]);
	}
	//encontrar o primeiro par
	i=0;
	while (i<T && v[i]%2 != 0) {
		i++;
	}
	//será que existe algum par?
	if (i<T) { //sim, existe
		mvp = v[i];
		for (j=i+1; j<T; j++) {
			if (v[j]%2 == 0 && v[j] > mvp) {
				mvp = v[j];
			}
		}
		printf ("\nMaior valor par encontrado = %d\n", mvp);
		printf ("\nj que saiu do laco = %d\n", j);
	}
	else { //não, não existe
		printf ("\nA lista de valores nao contem pares\n");
	}
	return 0;
}