//ler 2 valores e mostrar o maior
// 2 5 -> 5
// 8 4 -> 8
// 6 6 -> 6
#include <stdio.h>
int main (){
    float num1, num2;
    printf ("\nDigite 2 numeros: \n");
    scanf("%f%f",&num1,&num2);
    if(num1 > num2){
        printf ("\nMaior = %f\n", num1);
    }
    else{
        printf ("\nMaior = %f\n", num2);
    }
    return 0;
}
