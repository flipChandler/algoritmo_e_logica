#include <stdio.h>

int main () {
    int n;
    printf ("digite um numero inteiro de 3 digitos: ");
    scanf ("%d", &n);
    printf ("\nnumero invertido: ");
    printf ("%d", n % 10);
    n = n / 10;
    printf ("%d", n % 10);
    printf ("%d", n / 10);
    printf ("\n");
    return 0;
}
