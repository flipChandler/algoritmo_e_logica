int main () {
    int v[1000000];
    return 0;
}
