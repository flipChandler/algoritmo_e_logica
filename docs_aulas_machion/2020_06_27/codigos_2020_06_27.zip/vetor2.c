#include <stdio.h>
int main () {
    int v[5], i;
    for (i=0; i<5; i++) {
        v[i] = i+1;
        printf ("pos %d -> valor %d\n", i, v[i]);
    }
    return 0;
}
