//leitura segura de strings em C
#include <stdio.h>
int main () {
	char palavra[11];
	int i=0;
	char c;
	printf ("digite uma palavra: ");
	while (i<10 && ((c=getchar()) != '\n')) {
		palavra[i] = c;
		i++;
	}
	palavra[i] = '\0';
	printf ("\nvoce digitou %s\n", palavra);
	return 0;
}