#include <stdio.h>
int main () {
	char palavra1[10], palavra2[10];
	int i;
	printf ("digite uma palavra: ");
	scanf ("%s", palavra1);
	printf ("\nvoce digitou %s\n", palavra1);
	printf ("digite outra palavra: ");
	scanf ("%s", palavra2);
	printf ("\nvoce digitou %s\n", palavra2);
	return 0;
}