//ler uma matriz 3x3, encontrar e mostrar o maior elemento
#include <stdio.h>
#define T 3
int main () {
	int m[T][T], i, j, maior;
	//leitura da matriz
	printf ("digite os valores para a matriz (%dx%d)\n", T, T);
	for (i=0; i<T; i++) {
		for (j=0; j<T; j++) {
			printf ("posicao [%d][%d]: ", i, j);
			scanf ("%d", &m[i][j]);
		}
	}
	maior = m[0][0];
    for(i=0;i<T;i++){
        for(j=0;j<T;j++){
            if(m[i][j] > maior){
                maior = m[i][j];
            }
        }
    }
    printf("\nMaior Valor: %d", maior);
	return 0;
}