//ler uma matriz 3x3, exibir a matriz adequadamente, somar seus
//elementos e mostrar a somar
#include <stdio.h>
#define T 3
int main () {
	int m[T][T], i, j, soma=0;
	//leitura da matriz
	printf ("digite os valores para a matriz (%dx%d)\n", T, T);
	for (i=0; i<T; i++) {
		for (j=0; j<T; j++) {
			printf ("posicao [%d][%d]: ", i, j);
			scanf ("%d", &m[i][j]);
		}
	}
	//exibir a matriz adequadamente
	printf ("\nmatriz digitada:\n");
	for (i=0; i<T; i++) {
		for (j=0; j<T; j++) {
			printf ("%3d ", m[i][j]);
		}
		printf ("\n");
	}
	//somar os elementos
	for (i=0; i<T; i++) {
		for (j=0; j<T; j++) {
			soma = soma + m[i][j];
		}
	}
	//exibir a soma
	printf ("\nsoma = %d\n", soma);
	return 0;
}