#include <stdio.h>
#define T 3

int main() {
    int matriz[T][T], i, j, maior_valor_linha[T];
    
    printf("Digite os valores da matriz: ");
    
    for (i = 0; i < T; i++) {
        for (j = 0; j < T; j++) {
            printf ("\nPosicao [%d][%d]: ", i, j);
            scanf("%d", &matriz[i][j]);            
        }
    }
    
    for (i = 0; i < T; i++) {
        maior_valor_linha[i] = matriz[i][0];
        for (j = 1; j < T; j++) {
            if(matriz[i][j] > maior_valor_linha[i]) {
                maior_valor_linha[i] = matriz[i][j];
            }                        
        }
    }
    
    for (i = 0; i < T; i++) {
        printf ("\nMaior valor da linha %d = %d", i, maior_valor_linha[i]);
    }
    
    return 0;
}



<https://teams.microsoft.com/l/message/19:26d9ace1fdf84712884a4f92f1fc7580@thread.tacv2/1594476297030?tenantId=cf72e2bd-7a2b-4783-bdeb-39d57b07f76f&amp;groupId=31288626-9705-4e3f-a127-9d6312285925&amp;parentMessageId=1589020589814&amp;teamName=Algoritmos e Logica de Programacao-A-N-ADS-CRB-20201&amp;channelName=Geral&amp;createdTime=1594476297030>