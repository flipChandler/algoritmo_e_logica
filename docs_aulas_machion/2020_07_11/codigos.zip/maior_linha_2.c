//ler uma matriz 3x3, encontrar o maior elemento de cada linha, 
//armazenando-os num vetor e depois exibir esse vetor
#include <stdio.h>
#include <limits.h>
#define T 3
int main(){
    int m[T][T], mvl[T], i, j;
    printf("Digite os valores da matriz(%dx%d): \n", T, T);
    for(i=0;i<T;i++){
        mvl[i]=INT_MIN;
        for(j=0;j<T;j++){
            printf("posicao[%d][%d]: ", i, j);
            scanf("%d", &m[i][j]);
            if(m[i][j] > mvl[i]){
                mvl[i] = m[i][j];
            }
        }
    }
    for(i=0;i<T;i++)
        printf("\n%d",mvl[i]);
    return 0;
}