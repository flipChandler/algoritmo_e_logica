#include <stdio.h>

int main () {
    int i = 2000000000;
    printf ("%d", 2*i);
    return 0;
}
