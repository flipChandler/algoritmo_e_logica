//ler um inteiro entre 0 e 12 (inclu�dos), validar com do-while
//calculem e mostrem o fatorial do n�mero lido (while):
//n! = n x (n-1) x (n-2) x ... x 1

#include <stdio.h>

int main () {
    //declara��o e inicialioza��o das vari�veis
    int n, cont, fat=1;
    //entrada de dados com valida��o
    do {
        printf("digite um inteiro entre 0 e 12 (incluidos): ");
        scanf ("%d", &n);
    } while (n<0 || n>12);
    //processamento: c�lculo do fatorial
    cont = n;
    while (cont > 1) {
        fat = fat * cont;
        cont--;
    }
    //sa�da
    printf ("\nfatorial de %d = %d\n", n, fat);
    return 0;
}
