#include <stdio.h>

int main () {
    int a = 20;
    printf ("\nvalor de a = %d", a);
    printf ("\nendereco de a na memoria = %X\n", &a);
    return 0;
}
