// ler um valor n > 0 (validar), depois ler mais
// n n�meros e somar os m�ltiplos de 3
// um dos la�os com while, outro com do-while
#include <stdio.h>

int main(){
    int n, num, mult3 = 0, cont = 0, soma = 0;
    do{
        printf("Digite o numero de repeti�oes: ");
        scanf("%d", &n);
    } while(n <= 0);
    while(cont < n){
        printf("\nDigite um inteiro: ");
        scanf("%d", &num);
        if(num % 3 == 0){
            soma = soma  + num;
            mult3++;
        }
        cont++;
    }
    printf("\nQuantidade de multiplos de 3: %d
             \nSoma dos valores multiplos de 3: %d",
             mult3, soma);
    return 0;
}
