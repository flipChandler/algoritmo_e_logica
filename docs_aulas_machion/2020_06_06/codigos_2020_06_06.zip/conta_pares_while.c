//ler 10 valores e verificar quantos pares
//foram digitados

//-> usando while

#include <stdio.h>

int main () {
    int n, // armazena valores que o usu�rio digita
    cont, // controla o la�o
    cont_par; // conta quantos pares foram digitados
    cont = 1;
    cont_par = 0;
    while (cont <= 10) {
        printf ("digite um inteiro: ");
        scanf ("%d", &n);
        if (n%2 == 0) {
            cont_par++;
        }
        cont++;
    }
    printf ("\nforam digitados %d par(es)\n", cont_par);
    return 0;
}
