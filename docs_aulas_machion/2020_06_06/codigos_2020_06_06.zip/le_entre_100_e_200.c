//ler um valor inteiro entre 100 e 200.

#include <stdio.h>

int main () {
    int n;
    do {
        printf ("\ndigite um numero entre 100 e 200: ");
        scanf ("%d", &n);
    } while (n < 100 || n > 200);
    printf ("\nobrigada, volte sempre\n");
    return 0;
}
