//soma de fra��es

#include <stdio.h>

int main(){
    float n1 = 1, n2 = 10, s = 0;
    while(n1 <= 10){
        s = s + n1/n2;
        n1++;
        n2--;
    }
    printf("S: %f", s);
    return 0;
}
