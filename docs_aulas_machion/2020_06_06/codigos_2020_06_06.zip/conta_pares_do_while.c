//ler 10 valores e verificar quantos pares
//foram digitados

//-> usando do-while

#include <stdio.h>

int main () {
    //declara��o de vari�veis
    int n, cont=1, cont_par=0;

    //entrada e processamento
    do {
        printf ("\ndigite um inteiro: ");
        scanf ("%d", &n);
        if (!(n%2)) {
            cont_par++;
        }
        cont++;
    } while (cont <= 10);

    //sa�da
    printf ("\nForam digitados %d par(es)\n", cont_par);
    return 0;
}
